package lab5;

public class Data2 extends Data {

	public Data2() {
		n = 5;
		n_commercial = 7;
		n_residential = 18;
		point_distribution = new int[] { -5, -4, -3, 3, 4, 5 };

	}
}
