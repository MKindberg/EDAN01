package lab5;

public class Data3 extends Data {

	public Data3() {
		n = 7;
		n_commercial = 20;
		n_residential = 29;
		point_distribution = new int[] { -7, -6, -5, -4, 4, 5, 6, 7 };
		;

	}
}
