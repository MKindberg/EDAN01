package lab5;

public class Data1 extends Data {

	public Data1() {
		n = 5;
		n_commercial = 13;
		n_residential = 12;
		point_distribution = new int[] { -5, -4, -3, 3, 4, 5 };

	}
}
