package lab5;

public abstract class Data {
	int n;
	int n_commercial;
	int n_residential;
	int[] point_distribution;

}
