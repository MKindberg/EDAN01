package lab4;

public class Data {
	int del_add;
	int del_mul;

	int number_add;
	int number_mul;
	int n;

	int[] last;

	int[] add;

	int[] mul;

	int[][] dependencies;

}
